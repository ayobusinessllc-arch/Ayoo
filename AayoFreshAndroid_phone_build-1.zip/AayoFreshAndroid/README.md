# Aayo Fresh Business Manager — Android project

This is an Android WebView wrapper around the existing Aayo Fresh Injera + Baltina manager HTML. It is source code, not a prebuilt APK.

## Build from your phone using GitHub Actions

1. Sign in to GitHub in your phone browser (create a GitHub account if needed).
2. Create a new repository. Upload the contents of this `AayoFreshAndroid` folder to the repository root (so `settings.gradle`, `build.gradle`, and `app/` are at the top level). Include the hidden `.github` folder and its `workflows/build-apk.yml` file.
3. Open the repository's **Actions** tab. If prompted, enable Actions.
4. Select **Build Aayo Fresh APK** and tap **Run workflow** (or push to `main` to trigger it automatically).
5. Wait for the run to finish successfully. Open that run, scroll to **Artifacts**, and download `AayoFresh-debug-APK`. Extract the ZIP and install `app-debug.apk`. Android may ask you to allow installation from your browser/files app.

## Important limitations

- This workflow builds a debug APK in GitHub's cloud; it does not prove the app is fully functionally tested.
- The bundled HTML is the prior V6 baseline. The date aggregation bug is not yet confirmed fixed by this wrapper.
- Chrome HTML-file storage does not automatically transfer into the installed Android app's WebView storage. Export a backup from the old app first if possible, and do not clear Chrome data or delete the old HTML.
- Keep any business-data backup safe. Test using sample records before relying on totals.
